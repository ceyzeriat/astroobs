"""
Provides astronomy ephemeris to plan telescope observations
"""

#__all__ = ['astroobs'] # and all new files that should appear in "misc." listing

#from astroobs import *
