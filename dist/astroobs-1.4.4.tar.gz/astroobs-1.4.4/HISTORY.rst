1.4.4 (2016-08-06)
++++++++++++++++++

- Changed license to GNU
- Updated documentation
- Added show_all_obs() to show all available observatories
- Automated the version management
- Added disclaimer at import
- Set default legend parameter to True in plot() and polar()
- Fixed deprecation warning at display of Target

1.0.0 (2016-05-03)
++++++++++++++++++

- Initial release.
